﻿namespace Turbo.Plugins.Default
{
    public interface IFader
    {
        bool TestVisiblity(bool visibleTestResult);
    }
}