//################################################################################
//# ..:: created with TCT Version 5.2 for THUD v7.4 (17.11.4.1) ::.. by RealGsus #
//################################################################################

using Turbo.Plugins.Default;

namespace Turbo.Plugins.TCT
{

    public class TCTInventoryAndStashPlugin : BasePlugin, ICustomizer
    {

        public TCTInventoryAndStashPlugin()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
        }

        public void Customize()
        {
            Hud.GetPlugin<InventoryAndStashPlugin>().LooksGoodDisplayEnabled = true;
            Hud.GetPlugin<InventoryAndStashPlugin>().NotGoodDisplayEnabled = false;
        }

    }

}
