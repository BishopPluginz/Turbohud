﻿using System;
using System.Linq;
using Turbo.Plugins.Default;

namespace Turbo.Plugins.Bishop
{
    public class WizardBuffCustomizerPlugin : BasePlugin, ICustomizer
    {
        public WizardBuffCustomizerPlugin()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
        }

        public void Customize()
        {
            Hud.GetPlugin<BuffListPlugin>().BuffPainter.TimeLeftFont = Hud.Render.CreateFont("tahoma", 12, 255, 255, 255, 255, false, false, 255, 0, 0, 0, true);
            Hud.GetPlugin<BuffListPlugin>().BuffPainter.StackFont = Hud.Render.CreateFont("tahoma", 12, 255, 255, 255, 255, false, false, 255, 0, 0, 0, true);
            Hud.GetPlugin<BuffListPlugin>().BuffPainter.ShowTooltips = false;
			Hud.GetPlugin<BuffListPlugin>().PositionOffsetX = 0.633f;
            Hud.GetPlugin<BuffListPlugin>().PositionOffsetH = 0.5f;
            Hud.GetPlugin<BuffListPlugin>().RuleCalculator.SizeMultiplier = 0.9f;

            Hud.GetPlugin<BuffListPlugin>().RuleCalculator.Rules.Add(new BuffRule(243141) { IconIndex = 5, MinimumIconCount = 0, ShowStacks = true, ShowTimeLeft = true }); 

// BlackHole
            Hud.GetPlugin<BuffListPlugin>().RuleCalculator.Rules.Add(new BuffRule(30796) { IconIndex = 2, MinimumIconCount = 0, ShowStacks = true, ShowTimeLeft = false }); 
// Wafe of Force
            Hud.GetPlugin<BuffListPlugin>().RuleCalculator.Rules.Add(new BuffRule(208823) { IconIndex = 1, MinimumIconCount = 0, ShowStacks = true, ShowTimeLeft = false }); 
// ArcaneDynamo
            Hud.GetPlugin<BuffListPlugin>().RuleCalculator.Rules.Add(new BuffRule(74499) { IconIndex = 4, MinimumIconCount = 0, ShowStacks = true, ShowTimeLeft = false }); 
// HaloOfKarini
            Hud.GetPlugin<BuffListPlugin>().RuleCalculator.Rules.Add(new BuffRule(359581) { IconIndex = 5, MinimumIconCount = 0, ShowStacks = true, ShowTimeLeft = true }); 
// Firebird's Finery 6set
         }
	}
}