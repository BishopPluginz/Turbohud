using System.Collections.Generic;
using System.Linq;

using Turbo.Plugins.Default;

namespace Turbo.Plugins.gjuz
{
    public class MonsterKrysbinPlugin : BasePlugin, IInGameTopPainter
    {
		public bool DrawAtBoss { get; set; }			//Krysbin for Boss
		public bool DrawAtElite { get; set; }			//Krysbin for Elites
		public float SizeMultiplier { get; set; }		//iconSize Multiplier
		public float opacityMultiplier { get; set; }	//opacity Multiplier - single Krysbin (NOT Full Krysbin)
		
		//position offset
		public float OffsetX { get; set; }
		public float OffsetY { get; set; }
		
		private float StandardIconSize { get{ return 55f / 1200.0f * Hud.Window.Size.Height * SizeMultiplier; } }
		private bool inGRift { get{ return Hud.Game.SpecialArea == SpecialArea.GreaterRift; } }
		public List<HeroClass> DrawForHeroClass { get; set; }

        public MonsterKrysbinPlugin()
        {
            Enabled = true;
			
			DrawAtBoss = true;
			DrawAtElite = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
			
			OffsetX = 0f;
			OffsetY = 0f;
			
			SizeMultiplier = 0.65f;
			opacityMultiplier = 0.35f;
			DrawForHeroClass = new List<HeroClass>();
			DrawForHeroClass.Add(HeroClass.Necromancer);
        }

        public void PaintTopInGame(ClipState clipState)
        {
            if (clipState != ClipState.BeforeClip) return;
			if (!inGRift) return;
			if (!isKrybinEquipped()) return;		//no krysbin -> nothing to draw
			if (DrawForHeroClass.Any() && !DrawForHeroClass.Contains(Hud.Game.Me.HeroClassDefinition.HeroClass)) return;
			
			var bosses = Hud.Game.AliveMonsters.Where(m => m.Rarity == ActorRarity.Boss);
			if (DrawAtBoss && bosses.Any())
			{
				IMonster boss = bosses.FirstOrDefault();
				DrawKrysbin(boss);
			}
			
			if (DrawAtElite)
			{
				foreach (var elite in Hud.Game.AliveMonsters.Where(m => m.Rarity == ActorRarity.Rare || m.Rarity == ActorRarity.Champion))
				{	//no minions
					//no clones
					if (elite.SummonerAcdDynamicId != 0)
						continue;
					
					DrawKrysbin(elite);
				}
			}
        }
		
		private void DrawKrysbin(IMonster elite)
		{
			if (elite == null) return;							//no elite
			var StateKrysbin = isKrysbin(elite);
			if (StateKrysbin == 0) return;						//no krysbin_debuff
			
			uint itemSno = 1236308205;							//1236308205 - KrysbinsSentence_ItemSno
			var snoItem = Hud.Inventory.GetSnoItem(itemSno);
			
			//buff position
			IScreenCoordinate sc = elite.FloorCoordinate.ToScreenCoordinate();
			var itemRect = new System.Drawing.RectangleF(sc.X - StandardIconSize/2 + OffsetX, sc.Y + OffsetY, StandardIconSize, StandardIconSize);
			
			//buff strenght -> opacity
			float opacity = StateKrysbin == 1 ? opacityMultiplier : 1.0f;
			
			var slotTexture = Hud.Texture.InventorySlotTexture;
            slotTexture.Draw(itemRect.X, itemRect.Y, itemRect.Width, itemRect.Height, opacity);
			
			var backgroundTexture = Hud.Texture.InventoryLegendaryBackgroundSmall;
            backgroundTexture.Draw(itemRect.X, itemRect.Y, itemRect.Width, itemRect.Height, opacity);
			
			var itemTexture = Hud.Texture.GetItemTexture(snoItem);
            if (itemTexture != null)
            {
                itemTexture.Draw(itemRect.X, itemRect.Y, itemRect.Width, itemRect.Height, opacity);
            }
		}
		
		private bool isKrybinEquipped()
		{	//is a player with krysbin equipped ingame?
			foreach (var p in Hud.Game.Players.Where(p => p.HeroClassDefinition.HeroClass == HeroClass.Necromancer))
			{
				IBuff _bKrysbin = p.Powers.GetBuff(475241);					//get buff wegen cube	// Sno: 475241
				if (_bKrysbin != null && _bKrysbin.Active) return true;		//krysbin in use
			}
			
			return false;
		}
		
		private uint isKrysbin(IMonster elite)
		{
			if (elite.Frozen || elite.Stunned || elite.Blind)
				return 2;
			if (elite.Slow || elite.Chilled)
				return 1;
			
			return 0;
		}

    }

}