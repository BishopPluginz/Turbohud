namespace Turbo.Plugins.Default
{
    public interface IRotationTransformator
    {
        float TransformRotation(float angle);
    }
}