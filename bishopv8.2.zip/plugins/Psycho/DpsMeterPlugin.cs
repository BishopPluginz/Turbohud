using Turbo.Plugins.Default;
namespace Turbo.Plugins.Psycho
{
    public class DPSMeterPlugin : BasePlugin, IInGameTopPainter
    {
        public TopLabelDecorator DpsLabelDecorator { get; set; }

        private long HighestDPS;

        public DPSMeterPlugin()
        {
            Enabled = true;
        }
        public override void Load(IController hud)
        {
            base.Load(hud);

            HighestDPS = 0;

            DpsLabelDecorator = new TopLabelDecorator(Hud)
            {
                TextFont = Hud.Render.CreateFont("tahoma", 12, 255, 255, 255, 155, true, false, false),
                BackgroundTexture1 = hud.Texture.ButtonTextureBlue,
                BackgroundTexture2 = hud.Texture.BackgroundTextureBlue,
                BackgroundTextureOpacity2 = 0.1f,

                TextFunc = () => ValueToString(Hud.Game.Me.Damage.CurrentDps, ValueFormat.LongNumber),
                HintFunc = () => ValueToString(HighestDPS, ValueFormat.LongNumber),
            };
        }
        public void PaintTopInGame(ClipState clipState)
        {
            if (Hud.Game.Me.Damage.CurrentDps > HighestDPS) HighestDPS = Hud.Game.Me.Damage.CurrentDps;

            var xPos = 3350f;
            var yPos = 1975f;
            var bgWidth = Hud.Window.Size.Width * 0.07f;
            var bgHeight = Hud.Window.Size.Height * 0.04f;

            if (clipState == ClipState.BeforeClip)
            {
                DpsLabelDecorator.Paint(xPos - (bgWidth / 2), yPos, bgWidth, bgHeight, HorizontalAlign.Center);
            }
        }
    }
}