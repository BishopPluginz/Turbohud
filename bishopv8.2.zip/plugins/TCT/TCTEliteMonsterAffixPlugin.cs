//################################################################################
//# ..:: created with TCT Version 5.2 for THUD v7.4 (17.11.4.1) ::.. by RealGsus #
//################################################################################

using Turbo.Plugins.Default;

namespace Turbo.Plugins.TCT
{

    public class TCTEliteMonsterAffixPlugin : BasePlugin, ICustomizer
    {

        public TCTEliteMonsterAffixPlugin()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
        }

        public void Customize()
        {
            //##### ARCANE #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Arcane, "ARC");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Arcane);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Arcane, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 120, 0, 120, 0),
            }
            ));
            //##### AVENGER #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Avenger, "Avenger");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Avenger);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Avenger, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### DESECRATOR #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Desecrator, "DES");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Desecrator);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Desecrator, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 170, 50, 0, 0),
            }
            ));
            //##### ELECTRIFIED #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Electrified, "ELEC");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Electrified);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Electrified, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 40, 40, 240, 0),
            }
            ));
            //##### EXTRAHEALTH #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.ExtraHealth, "EHealth");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.ExtraHealth);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.ExtraHealth, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### FAST #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Fast, "Fast");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Fast);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Fast, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### FIRECHAINS #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.FireChains, "FCHAIN");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.FireChains);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.FireChains, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 170, 50, 0, 0),
            }
            ));
            //##### FROZEN #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Frozen, "FZN");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Frozen);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Frozen, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 0, 0, 120, 0),
            }
            ));
            //##### FROZENPULSE #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.FrozenPulse, "FPULSE");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.FrozenPulse);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.FrozenPulse, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 0, 0, 120, 0),
            }
            ));
            //##### HEALTHLINK #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.HealthLink, "HLink");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.HealthLink);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.HealthLink, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 0, 176, 80, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### HORDE #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Horde, "Horde");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Horde);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Horde, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### ILLUSIONIST #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Illusionist, "Illu");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Illusionist);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Illusionist, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### JAILER #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Jailer, "JAIL");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Jailer);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Jailer, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 120, 0, 120, 0),
            }
            ));
            //##### JUGGERNAUT #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Juggernaut, "JUGGER");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Juggernaut);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Juggernaut, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 255, 0, 0, 0),
            }
            ));
            //##### KNOCKBACK #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Knockback, "KBack");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Knockback);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Knockback, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### MISSILEDAMPENING #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.MissileDampening, "MDamp");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.MissileDampening);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.MissileDampening, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### MOLTEN #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Molten, "MOLTEN");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Molten);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Molten, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 170, 50, 0, 0),
            }
            ));
            //##### MORTAR #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Mortar, "MTAR");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Mortar);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Mortar, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 170, 50, 0, 0),
            }
            ));
            //##### NIGHTMARISH #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Nightmarish, "Nightmare");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Nightmarish);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Nightmarish, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### ORBITER #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Orbiter, "ORBIT");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Orbiter);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Orbiter, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 40, 40, 240, 0),
            }
            ));
            //##### PLAGUED #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Plagued, "PLAG");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Plagued);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Plagued, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 204, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(204, 0, 120, 0, 0),
            }
            ));
            //##### POISON #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Poison, "POISEN");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Poison);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Poison, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 0, 120, 0, 0),
            }
            ));
            //##### REFLECT #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Reflect, "REFLECT");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Reflect);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Reflect, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 120, 50, 0, 0),
            }
            ));
            //##### SHIELDING #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Shielding, "SHIELD");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Shielding);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Shielding, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 255, 0, 0, 0),
            }
            ));
            //##### TELEPORTER #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Teleporter, "Teleport");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Teleporter);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Teleporter, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### THUNDERSTORM #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Thunderstorm, "TSTORM");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Thunderstorm);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Thunderstorm, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 255, 255, 255, true, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 40, 40, 240, 0),
            }
            ));
            //##### VORTEX #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Vortex, "Vortex");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Vortex);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Vortex, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### WALLER #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Waller, "Waller");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Waller);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Waller, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
            //##### WORMHOLE #####
            Hud.GetPlugin<EliteMonsterAffixPlugin>().CustomAffixNames.Add(MonsterAffix.Wormhole, "Wormhole");
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Remove(MonsterAffix.Wormhole);
            Hud.GetPlugin<EliteMonsterAffixPlugin>().AffixDecorators.Add(MonsterAffix.Wormhole, new WorldDecoratorCollection(
            new GroundLabelDecorator(Hud)
            {
                BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2),
                TextFont = Hud.Render.CreateFont("tahoma", 6f, 255, 200, 220, 120, false, false, false),
                BackgroundBrush = Hud.Render.CreateBrush(255, 50, 50, 50, 0),
            }
            ));
        }

    }

}
