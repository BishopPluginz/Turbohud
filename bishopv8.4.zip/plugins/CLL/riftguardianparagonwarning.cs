using System;
using System.Linq;
using Turbo.Plugins.Default;
using System.Collections.Generic;

namespace Turbo.Plugins.CLL
{
    public class RiftGuardianParagonWarning : BasePlugin, IInGameTopPainter
    {
        public IFont RGParagonWarningFont { get; set; }
        public int MainStatCap { get; set; }
        private float HudWidth { get { return Hud.Window.Size.Width; } }
        private float HudHeight { get { return Hud.Window.Size.Height; } }
        public float ParaWarningX { get; set; }
        public float ParaWarningY { get; set; }
        public int ParagonInMovementSpeed { get; set; }
        public int baseMainStat { get; set; }
        public string WarningMessage { get; set; }
        public bool AlertBeforeBossSpawns { get; set; }
        public double PercentageWhenToAlert { get; set; }
        public float OffsetX { get; set; }
        public float OffsetY { get; set; }

        public RiftGuardianParagonWarning()
        {
            Enabled = true;
        }


        public override void Load(IController hud)
        {
            base.Load(hud);

            RGParagonWarningFont = Hud.Render.CreateFont("calibri", 20, 255, 255, 0, 0, true, false, true);
            //if someone chooses to use Paragon points in Movement speed
            ParagonInMovementSpeed = 0;
            //Position left/right. Higer number = further right
            OffsetX = 0.4f;
            //Position up/down. Higer number = further down
            OffsetY = 0.25f;
            //270 because every level 70 necro has 217 int without paragon or gear
            baseMainStat = 217;
            //The Message that is displayed
            WarningMessage = "Switch Paragon!";
            //true when the alert should be shown before the boss is spawned
            AlertBeforeBossSpawns = false;
            //Percentage when the Alert should be shown
            PercentageWhenToAlert = 95;
        }

        public void PaintTopInGame(ClipState clipState)
        {
            if (clipState != ClipState.BeforeClip) return;
            if (Hud.Game.Me.HeroClassDefinition.HeroClass != HeroClass.Necromancer) return;
            ParaWarningY = HudHeight * OffsetY;
            ParaWarningX = HudWidth * OffsetX;

            #region CalculatingMainStat
            int GearMainStat = 0;
            int CaldesannMainStat = 0;
            foreach (IItem item in Hud.Game.Items.Where(item => item.Location.IsEquipped()))
            {
                foreach (IItemStat stat in item.StatList)
                {
                    IAttribute at = stat.Attribute;
                    if (stat.Id == "main_stat")
                    {
                        //MainStat from gear + gems
                        GearMainStat += Convert.ToInt32(stat.Value);
                    }
                }
                //Minimum level caldessan is level 50 and gives 250 mainstat, every other level adds 5 int
                CaldesannMainStat += 250 + ((item.CaldesannRank - 50) * 5);
            }
            //Int without paragon.
            int MainStatTotalWOParagon = GearMainStat + baseMainStat + CaldesannMainStat;

            //600 Points go into Offense,Defense and Utility, 50 points in MaxEssence, up to 50 points in Movementspeed if needed
            int MainStatParagonPoints = Convert.ToInt32(Hud.Game.Me.CurrentLevelParagon) - 600 - 50 - ParagonInMovementSpeed;

            //each paragon point in main stat adds 5 int
            int MainStatParagonIntValue = MainStatParagonPoints * 5;
            int MainStatTotal = MainStatTotalWOParagon + MainStatParagonIntValue;

            #endregion


            #region Rift Guardian Paragon Warning
            if (!(Hud.Game.Me.Stats.MainStat < MainStatTotal)) return;
            if (AlertBeforeBossSpawns)
            {
                if (Hud.Game.RiftPercentage >= PercentageWhenToAlert)
                {
                    RGParagonWarningFont.DrawText(WarningMessage, ParaWarningX, ParaWarningY);
                }
            }
            else
            {
                if (IsGuardianAlive)
                {
                    RGParagonWarningFont.DrawText(WarningMessage, ParaWarningX, ParaWarningY);
                }
            }
            #endregion
        }

        public bool IsGuardianAlive
        {
            get
            {
                return riftQuest != null && (riftQuest.QuestStepId == 16);
            }
        }

        private IQuest riftQuest
        {
            get
            {
                return Hud.Game.Quests.FirstOrDefault(q => q.SnoQuest.Sno == 337492) ?? // rift
                       Hud.Game.Quests.FirstOrDefault(q => q.SnoQuest.Sno == 382695);   // gr           
            }
        }
    }
    public static class EquipExtension
    {
        public static bool IsEquipped(this ItemLocation location)
        {
            return location >= ItemLocation.Head && location <= ItemLocation.Neck;
        }
    }
}