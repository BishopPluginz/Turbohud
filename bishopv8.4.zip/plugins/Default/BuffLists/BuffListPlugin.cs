namespace Turbo.Plugins.Default
{

    public class BuffListPlugin : BasePlugin, IInGameTopPainter
    {

        public BuffPainter BuffPainter { get; set; }
        public BuffRuleCalculator RuleCalculator { get; private set; }
        public float PositionOffsetX { get; set; }
        public float PositionOffsetH { get; set; }
        public BuffListPlugin()
        {
            Enabled = true;
            PositionOffsetX = 0.5f;
            PositionOffsetH = 0.005f;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);

            BuffPainter = new BuffPainter(Hud, true)
            {
                Opacity = 1f,
                ShowTimeLeftNumbers = false,
                ShowTooltips = false,
                TimeLeftFont = Hud.Render.CreateFont("calibri", 7, 255, 255, 255, 255, false, false, 255, 0, 0, 0, true),
                StackFont = Hud.Render.CreateFont("calibri", 6, 255, 255, 255, 255, false, false, 255, 0, 0, 0, true),
            };

            RuleCalculator = new BuffRuleCalculator(Hud);
            RuleCalculator.SizeMultiplier = 1f;
        }

        public void PaintTopInGame(ClipState clipState)
        {
            if (Hud.Render.UiHidden) return;
            if (clipState != ClipState.BeforeClip) return;

            RuleCalculator.CalculatePaintInfo(Hud.Game.Me);
            if (RuleCalculator.PaintInfoList.Count == 0) return;

            var x = Hud.Window.Size.Width * PositionOffsetX;
            var h = Hud.Window.Size.Height * PositionOffsetH;
			var w = Hud.Window.Size.Width * 0.029f;
            BuffPainter.PaintHorizontalCenter(RuleCalculator.PaintInfoList, x, w, h, RuleCalculator.StandardIconSize, RuleCalculator.StandardIconSpacing);
        }

    }

}