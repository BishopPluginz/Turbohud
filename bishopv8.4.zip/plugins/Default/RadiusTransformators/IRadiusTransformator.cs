namespace Turbo.Plugins.Default
{
    public interface IRadiusTransformator
    {
        float TransformRadius(float radius);
    }
}