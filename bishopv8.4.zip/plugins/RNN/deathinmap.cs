using Turbo.Plugins.Default;
 
namespace Turbo.Plugins.RNN
{
    public class DeathInMap : BasePlugin, IInGameWorldPainter
    {
        private IFont RedFont { get; set; }
        private IFont GreenFont { get; set; }
        private IFont GrisFont { get; set; }
        public float XPorc { get; set; }
        public float YPorc { get; set; }
		public bool ShowInTown { get; set; }
		
        public DeathInMap()
        {
            Enabled = true;
        }
        public override void Load(IController hud)
        {
            base.Load(hud);
            XPorc = 0.825f;
            YPorc = 0.047f;
			ShowInTown = true;

            RedFont = Hud.Render.CreateFont("calibri", 8f, 220, 250, 0, 0, false, false, 128, 0, 0, 0, true) ;
            GreenFont = Hud.Render.CreateFont("calibri", 8f, 220, 0, 250, 0, false, false, 128, 0, 0, 0, true) ;
			GrisFont = Hud.Render.CreateFont("calibri", 7f, 220, 180, 180, 180, false, false, 128, 0, 0, 0, true) ;	
        }
 
        public void PaintWorld(WorldLayer layer)
        {            
            if (Hud.Game.IsInGame ) {
               if (ShowInTown || !Hud.Game.Me.IsInTown) {
                  if ( Hud.Game.NumberOfPlayersInGame > 1 )  {
                     bool Vivos = true; bool EnMapa = true ; var Jugando = 0 ; string Jugador = string.Empty ; uint MapaSno = Hud.Game.Me.SnoArea.Sno ; IFont TextFont = null ;
                     foreach (var player in Hud.Game.Players) {
               	        if (player.IsDead) Vivos = false;
                        if (player.SnoArea.Sno != MapaSno) { EnMapa = false; Jugador = player.BattleTagAbovePortrait; }
                        else { Jugando++ ; }
                      }
                     var xpos = Hud.Window.Size.Width * XPorc;  var ypos = Hud.Window.Size.Height * YPorc;

                     TextFont = (Vivos == true) ? GreenFont : RedFont ;  
                     TextFont.DrawText(TextFont.GetTextLayout("☠️"), xpos, ypos ); 

                     TextFont = (EnMapa == true) ? GreenFont : RedFont ; 
                     TextFont.DrawText(TextFont.GetTextLayout("🏴"), xpos + 25, ypos ); 

                     var d =  (Hud.Game.NumberOfPlayersInGame - Jugando == 1) ?  " [" + Jugador + "]" : " [" + Jugando + "/" +  Hud.Game.NumberOfPlayersInGame + "]";
                     GrisFont.DrawText(GrisFont.GetTextLayout(d) , xpos + 41, ypos + 1 );  
                  }
              }
           }
        }
    }
}