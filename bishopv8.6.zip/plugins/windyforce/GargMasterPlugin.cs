using System.Collections.Generic;
using System.Linq;
using Turbo.Plugins.Default;
 
namespace Turbo.Plugins.WindyForce
{
    public class GargsMasterPlugin : BasePlugin, IInGameWorldPainter
    {
        public WorldDecoratorCollection PlayerGargs { get; set; }
        public WorldDecoratorCollection OtherPlayersGargs { get; set; }
        public HashSet<uint> GargSno = new HashSet<uint>
        {
            432690, 432691, 432692, 432693, 432694, 122305, 179776, 171491, 179778, 171501, 171502, 179780, 179779, 179772
        };
 
        public GargsMasterPlugin()
        {
            Enabled = true;
        }
 
        public override void Load(IController hud)
        {
            base.Load(hud);
 
            PlayerGargs = new WorldDecoratorCollection(
                new MapShapeDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(255, 34, 200, 34, 2),
                    ShapePainter = new CircleShapePainter(Hud),
                    Radius = 10f,
		    RadiusTransformator = new StandardPingRadiusTransformator(Hud, 600)
                    {
                        RadiusMinimumMultiplier = 0.25f
                    }
                },
                new GroundCircleDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(255, 0, 255, 0, 5, SharpDX.Direct2D1.DashStyle.Dash),
                    Radius = -2,
		    RadiusTransformator = new StandardPingRadiusTransformator(Hud, 600)
                    {
                        RadiusMinimumMultiplier = 0.25f
                    }
                });
 
            OtherPlayersGargs = new WorldDecoratorCollection(
                new MapShapeDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(0, 128, 0, 0, 2),
                    ShapePainter = new CircleShapePainter(Hud),
                    Radius = 6f,
                },
                new GroundCircleDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(0, 128, 0, 0, 5, SharpDX.Direct2D1.DashStyle.Dash),
                    Radius = -2,
		    RadiusTransformator = new StandardPingRadiusTransformator(Hud, 600)
                    {
                        RadiusMinimumMultiplier = 0.25f
                    }
                });
        }
 
        public void PaintWorld(WorldLayer layer)
        {
            var player = Hud.Game.Me;            
            var actors = Hud.Game.Actors.Where(a => GargSno.Contains(a.SnoActor.Sno));
 
            foreach (var actor in actors)
            {            
                if (actor.SummonerAcdDynamicId == player.SummonerId)                
                    PlayerGargs.Paint(layer, actor, actor.FloorCoordinate, "");                
                else                
                    OtherPlayersGargs.Paint(layer, actor, actor.FloorCoordinate, "");                
            }
        }
    } // class
}