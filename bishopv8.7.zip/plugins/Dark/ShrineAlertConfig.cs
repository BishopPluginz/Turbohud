using Turbo.Plugins.Default;

namespace Turbo.Plugins.Dark
{
    public class ShrineAlertConfig : BasePlugin, ICustomizer
    {
        public ShrineAlertConfig()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
        }
		
        public void Customize()
        {
			Hud.RunOnPlugin<Dark.ShrineAlertPlugin>(plugin =>
			{
				// Shrine Alerts Examples
				// null = use localized name for that shrine
				// "" 	= no TTS for that shrine
				plugin.UseCustomNames = true;
				plugin.ShrineCustomNames[ShrineType.BlessedShrine] 		= "";
				plugin.ShrineCustomNames[ShrineType.EnlightenedShrine] 		= "";
				plugin.ShrineCustomNames[ShrineType.FortuneShrine] 		= "";
				plugin.ShrineCustomNames[ShrineType.FrenziedShrine] 		= "";
				plugin.ShrineCustomNames[ShrineType.EmpoweredShrine] 		= "";
				plugin.ShrineCustomNames[ShrineType.FleetingShrine] 		= "";
				plugin.ShrineCustomNames[ShrineType.PowerPylon] 		= "";
				plugin.ShrineCustomNames[ShrineType.ConduitPylon] 		= "";
				plugin.ShrineCustomNames[ShrineType.ChannelingPylon] 		= "";
				plugin.ShrineCustomNames[ShrineType.ShieldPylon] 		= "";
				plugin.ShrineCustomNames[ShrineType.SpeedPylon] 		= "";
				plugin.ShrineCustomNames[ShrineType.BanditShrine] 		= "";
				plugin.ShrineCustomNames[ShrineType.PoolOfReflection] 		= "";
				plugin.ShrineCustomNames[ShrineType.HealingWell] 		= "";
			});
        }
    }
}