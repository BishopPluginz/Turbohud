using System.Collections.Generic;
using Turbo.Plugins.Default;

namespace Turbo.Plugins.User
{
    public class MotherSummonerPlugin : BasePlugin, IInGameWorldPainter
    {

        public WorldDecoratorCollection Decorator { get; set; }
        private Dictionary<string, string> _names = new Dictionary<string, string>();

        public MotherSummonerPlugin()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);

            AddNames("Skeletal Summoner", "Tomb Guardian", "Returned Summoner", "Vengeful Summoner", "Retching Cadaver", "Wretched Mother", "Spewing Horror", "Deathspitter");

            Decorator = new WorldDecoratorCollection(
                new MapShapeDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(255, 150, 80, 255, 2.5f),
                    ShadowBrush = Hud.Render.CreateBrush(96, 0, 0, 0, 1),
                    ShapePainter = new CircleShapePainter(Hud),
                    Radius = 5,
                    RadiusTransformator = new StandardPingRadiusTransformator(Hud, 600)
                    {
                        RadiusMinimumMultiplier = 0.8f
                    }
                },
                new GroundCircleDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(255, 150, 80, 255, 6),
                    Radius = 2.0f,
                    RadiusTransformator = new StandardPingRadiusTransformator(Hud, 600)
                    {
                        RadiusMinimumMultiplier = 0.8f
                    }
                }
            );
        }

        public void AddNames(params string[] names)
        {
            foreach (var name in names)
            {
                _names[name] = name;
            }
        }

        public void RemoveName(string name)
        {
            if (_names.ContainsKey(name)) _names.Remove(name);
        }

        public void PaintWorld(WorldLayer layer)
        {
            var monsters = Hud.Game.AliveMonsters;
            foreach (var monster in monsters)
            {
                if (_names.ContainsKey(monster.SnoMonster.NameEnglish) || _names.ContainsKey(monster.SnoMonster.NameLocalized))
                {
                    Decorator.Paint(layer, monster, monster.FloorCoordinate, monster.SnoMonster.NameLocalized);
                }
            }
        }
    }
}
