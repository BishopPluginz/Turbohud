//################################################################################
//# ..:: created with TCT Version 5.2 for THUD v7.4 (17.11.4.1) ::.. by RealGsus #
//################################################################################

namespace Turbo.Plugins.Jack.Monsters
{
    using System;
    using Turbo.Plugins.Default;

    public class DangerousAffixMonsterConfig : BasePlugin, ICustomizer
    {
        public DangerousAffixMonsterConfig()
        {
            Enabled = true;
        }

        public void Customize()
        {
            //Debug(); return;
            Hud.RunOnPlugin<DangerousAffixMonsterPlugin>(plugin =>
            {
                plugin.DefineDangerousAffix(MonsterAffix.Arcane,
                    (a) => "A",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 0),
                    fgShapePainter: new CircleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionDecorators: true,
                    showMinionAffixesNames: true
                );
                plugin.DefineDangerousAffix(MonsterAffix.Electrified,
                    (a) => "\u26A1",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 0),
                    fgShapePainter: new CircleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionDecorators: true,
                    showMinionAffixesNames: true
                );
                plugin.DefineDangerousAffix(MonsterAffix.FrozenPulse,
                    (a) => "\u2744",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 0),
                    fgShapePainter: new CircleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionDecorators: true,
                    showMinionAffixesNames: true
                );
                plugin.DefineDangerousAffix(MonsterAffix.Illusionist,
                    (a) => "I",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 0),
                    fgShapePainter: new CircleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionDecorators: true,
                    showMinionAffixesNames: true
                );
                plugin.DefineDangerousAffix(MonsterAffix.Juggernaut,
                    (a) => "\u2620",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 1),
                    fgShapePainter: new RotatingTriangleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionAffixesNames: false
                );
                plugin.DefineDangerousAffix(MonsterAffix.Shielding,
                    (a) => "\u26E8",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 0),
                    fgShapePainter: new CircleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionDecorators: true,
                    showMinionAffixesNames: true
                );
                plugin.DefineDangerousAffix(MonsterAffix.Vortex,
                    (a) => "V",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 0),
                    fgShapePainter: new CircleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionDecorators: true,
                    showMinionAffixesNames: true
                );
                plugin.DefineDangerousAffix(MonsterAffix.Wormhole,
                    (a) => "W",
                    priority: 420,
                    bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                    bgShapePainter: new CircleShapePainter(Hud),
                    bgPing: true,
                    bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    bgEliteRadius: 8,
                    bgMinionRadius: 6,
                    fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 0),
                    fgShapePainter: new CircleShapePainter(Hud),
                    fgPing: true,
                    fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 500),
                    fgEliteRadius: 6,
                    fgMinionRadius: 6,
                    eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 255, 0, false, false, 128, 0, 0, 0, true),
                    showMinionDecorators: true,
                    showMinionAffixesNames: true
                );
            });
            Enabled = false;
        }

        public void Debug()
        {
            Hud.RunOnPlugin<DangerousAffixMonsterPlugin>(plugin =>
            {
                var p = 420;
                foreach (MonsterAffix affix in Enum.GetValues(typeof(MonsterAffix)))
                {
                    plugin.DefineDangerousAffix(affix,
                        (a) => a.NameLocalized.Substring(0, 3), // or a string like "Jug"
                        priority: p--, // higher first
                        // decorator background
                        bgBrush: Hud.Render.CreateBrush(255, 0, 0, 0, 0),
                        bgShapePainter: new CircleShapePainter(Hud), // default new CircleShapePainter(Hud)
                        bgPing: true, // default false
                        bgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 666),
                        bgEliteRadius: 8, // default 8
                        bgMinionRadius: 6, // default 6
                        // decorator foreground
                        fgBrush: Hud.Render.CreateBrush(255, 255, 0, 0, 1),
                        fgShapePainter: new RotatingTriangleShapePainter(Hud), // default new CircleShapePainter(Hud)
                        fgPing: false, // default false
                        fgRadiusTransformator: new StandardPingRadiusTransformator(Hud, 666),
                        fgEliteRadius: 6, // default 6
                        fgMinionRadius: 2, // default 2
                        // labels fonts
                        eliteFont: Hud.Render.CreateFont("calibri", 10f, 200, 255, 0, 0, false, false, 128, 0, 0, 0, true),
                        minionFont: Hud.Render.CreateFont("calibri", 7f, 200, 255, 0, 0, false, false, 128, 0, 0, 0, true),
                        // minions
                        showMinionDecorators: true, // default false
                        showMinionAffixesNames: true // default false
                        );
                }
            });
        }
    }
}
