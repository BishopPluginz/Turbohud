using System.Collections.Generic;
using Turbo.Plugins.Default;

namespace Turbo.Plugins.glq
{
    public class GLQ_EliteMonsterAffixPlugin : BasePlugin, IInGameWorldPainter
	{

        public WorldDecoratorCollection WeakDecorator { get; set; }
        public Dictionary<MonsterAffix, WorldDecoratorCollection> AffixDecorators { get; set; }
        public Dictionary<MonsterAffix, string> CustomAffixNames { get; set; }
        public int transparency { get; set; }
        public int fontsize { get; set; }

        public GLQ_EliteMonsterAffixPlugin()
		{
            Enabled = true;
            Order = 20000;
		}

        public override void Load(IController hud)
        {
            base.Load(hud);
            transparency = 150;
            fontsize = 6;
			CustomAffixNames = new Dictionary<MonsterAffix, string>();
            var BorderBrush = Hud.Render.CreateBrush(128, 0, 0, 0, 2);
			AffixDecorators = new Dictionary<MonsterAffix, WorldDecoratorCollection>();
            AffixDecorators.Add(MonsterAffix.Arcane, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 255, 255, 255, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 120, 0, 120, 0),
                }
                ));
            AffixDecorators.Add(MonsterAffix.Juggernaut, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 255, 255, 255, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 150, 0, 0, 0),
                }
                ));
            AffixDecorators.Add(MonsterAffix.Molten, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 255, 255, 255, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 130, 13, 0, 0),
                }
                ));
            AffixDecorators.Add(MonsterAffix.Waller, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 255, 255, 255, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 50, 50, 50, 0),
                }
                ));
            AffixDecorators.Add(MonsterAffix.HealthLink, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 255, 255, 255, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 128, 128, 255, 0),
                }
                ));		
            AffixDecorators.Add(MonsterAffix.FireChains, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 255, 255, 255, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 255, 0, 0, 0),
                }
                ));
			AffixDecorators.Add(MonsterAffix.Illusionist, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 0, 0, 0, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 166, 166, 255, 0),
                }
                ));	
            AffixDecorators.Add(MonsterAffix.Shielding, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 0, 0, 0, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 150, 180, 150, 0),
                }
                ));		
            AffixDecorators.Add(MonsterAffix.Teleporter, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 0, 0, 0, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 185, 185, 185, 0),
                }
                ));		
            AffixDecorators.Add(MonsterAffix.Wormhole, new WorldDecoratorCollection(
                new GroundLabelDecorator(Hud)
                {
                    BorderBrush = BorderBrush,
                    TextFont = Hud.Render.CreateFont("calibri", fontsize, 255, 255, 255, 255, true, false, false),
                    BackgroundBrush = Hud.Render.CreateBrush(transparency, 255, 0, 255, 0),
                }
                ));			
        }
        public void PaintWorld(WorldLayer layer)
        {

            var monsters = Hud.Game.AliveMonsters;
            foreach (var monster in monsters)
            {
				bool illusionist = false;
				if(monster.SummonerAcdDynamicId == 0)
				{
					illusionist = false;
				}
				else
				{
					illusionist = true;
				}
				if (monster.Rarity == ActorRarity.Normal || monster.Rarity == ActorRarity.Unique || monster.Rarity == ActorRarity.Boss) {
                foreach (var snoMonsterAffix in monster.AffixSnoList)
                {
                    WorldDecoratorCollection decorator;
                    if (!AffixDecorators.TryGetValue(snoMonsterAffix.Affix, out decorator)) continue;

                    string affixName = null;
                    if (CustomAffixNames.ContainsKey(snoMonsterAffix.Affix))
                    {
                        affixName = CustomAffixNames[snoMonsterAffix.Affix];
                    }
                    else affixName = snoMonsterAffix.NameLocalized;

                    decorator.Paint(layer, monster, monster.FloorCoordinate, affixName);
                }
				}
				
                if (monster.Rarity == ActorRarity.Champion)
				{
					if (illusionist == false)
					{
                	foreach (var snoMonsterAffix in monster.AffixSnoList)
                	{
                    	WorldDecoratorCollection decorator;
                    	if (!AffixDecorators.TryGetValue(snoMonsterAffix.Affix, out decorator)) continue;

                    	string affixName = null;
                    	if (CustomAffixNames.ContainsKey(snoMonsterAffix.Affix))
                    	{
                        	affixName = CustomAffixNames[snoMonsterAffix.Affix];
                    	}
                    	else affixName = snoMonsterAffix.NameLocalized;

                    	decorator.Paint(layer, monster, monster.FloorCoordinate, affixName);
                	}
					}
				}
				if (monster.Rarity == ActorRarity.Rare)
				{
					if (illusionist == false)
					{
                	foreach (var snoMonsterAffix in monster.AffixSnoList)
                	{
                    	WorldDecoratorCollection decorator;
                    	if (!AffixDecorators.TryGetValue(snoMonsterAffix.Affix, out decorator)) continue;

                    	string affixName = null;
                    	if (CustomAffixNames.ContainsKey(snoMonsterAffix.Affix))
                    	{
                        	affixName = CustomAffixNames[snoMonsterAffix.Affix];
                    	}
                    	else affixName = snoMonsterAffix.NameLocalized;

                    	decorator.Paint(layer, monster, monster.FloorCoordinate, affixName);
                	}
					}
				}
            }
        }

    }

}