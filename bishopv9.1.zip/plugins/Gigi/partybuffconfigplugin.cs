using Turbo.Plugins.Default;
namespace Turbo.Plugins.Gigi
{
    public class PartyBuffConfigPlugin : BasePlugin, ICustomizer
	{
        public PartyBuffConfigPlugin()
		{
            Enabled = false;
		}
        public void Customize()
        {
 
Hud.RunOnPlugin<PartyBuffPlugin>(plugin => 
{ 
    uint[] onWiz = {
		//onWiz
        

	}; 
    uint[] onMonk = {
		//onMonk

	}; 
    uint[] onWD = {
		//onWD
        
	}; 
    uint[] onBarb = {
		//onBarb
		
	}; 
    uint[] onCrus = {
		//onCrus
        
	}; 
    uint[] onDH = {
		//onDH
        
	}; 
    uint[] onAll = {
		//onAll
		208474,
		134872,
		317076,
		156484,
		79528,
		79607,
		217819,
		309830,
		129216,
		365311,
		129217,
		324770,
		440336,
		429855,
		423244,
		403404,
		266258,
		266254,
		262935,
		266271,
		402461,
		465839,
		465952,
	}; 
    uint[] onMe = {
		//onMe
		359583,
		476587,
		430289,
		449236,
		402458,
		318817,		
	};  
    //pass buffs to plugin -> apply them 
    uint[] onNec = {
		//onNec
		
	};
    plugin.DisplayOnAll(onAll); 
    plugin.DisplayOnMe(onMe); 
    plugin.DisplayOnClassExceptMe(HeroClass.Wizard, onWiz); 
    plugin.DisplayOnClassExceptMe(HeroClass.Necromancer, onNec); 
    plugin.DisplayOnClassExceptMe(HeroClass.Monk, onMonk); 
    plugin.DisplayOnClassExceptMe(HeroClass.Barbarian, onBarb); 
    plugin.DisplayOnClassExceptMe(HeroClass.WitchDoctor, onWD); 
    plugin.DisplayOnClassExceptMe(HeroClass.DemonHunter, onDH); 
    plugin.DisplayOnClassExceptMe(HeroClass.Crusader, onCrus); 
            }); 
        }
    }
}