using Turbo.Plugins.Default;

namespace Turbo.Plugins.One
{
    public class GRVoice : BasePlugin, IInGameWorldPainter
    {
        private bool inGRift { get; set; }
        public string GRSpeak { get; set; }
        public float GRProgress { get; set; }
        private bool statement { get; set; }
        public GRVoice()
        {
            Enabled = true;
            GRProgress = 95;
            GRSpeak = "GR progression";
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
            statement = true;
        }

        public void PaintWorld(WorldLayer layer)
        {
            inGRift = Hud.Game.SpecialArea == SpecialArea.GreaterRift;
            if (!inGRift) return;
            if (statement && Hud.Game.RiftPercentage >= GRProgress && Hud.Sound.LastSpeak.TimerTest(5000))
            {
                Hud.Sound.Speak(GRSpeak + GRProgress);
                statement = false;
                Hud.Sound.LastSpeak.Restart();
            }
            if (!statement && Hud.Game.RiftPercentage == 0) statement = true;
        }
    }
}