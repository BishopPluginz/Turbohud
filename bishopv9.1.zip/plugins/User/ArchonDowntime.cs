using System.Globalization;
using Turbo.Plugins.Default;
using System.Linq;
using SharpDX.DirectInput;

using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections.Generic;

namespace Turbo.Plugins.User
{
    using System.Text;


    public class ArchonDowntime : BasePlugin, IInGameTopPainter
    {
        private readonly int[] _skillOrder = { 2, 3, 4, 5, 0, 1 };
        private StringBuilder textBuilder;
        private StringBuilder textBuilder1;
        private IFont GreenFont;
        private IFont RedFont;
        private IFont RedBFont;
        double ArchonTimeLeft;
        double Cooldown;
        bool WizIngame;
        public ArchonDowntime()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
            GreenFont = Hud.Render.CreateFont("Tahoma", 10, 200, 0, 255, 0, true, false, false);
            RedFont = Hud.Render.CreateFont("Tahoma", 10, 200, 255, 0, 0, true, false, false);
            RedBFont = Hud.Render.CreateFont("Tahoma", 14, 255, 255, 255, 255, true, false, false);
            textBuilder = new StringBuilder();
            textBuilder1 = new StringBuilder();
        }


        public void PaintTopInGame(ClipState clipState)
        {
            if (Hud.Render.UiHidden) return;
            float x = Hud.Window.Size.Width * 0.72f;
            float y = Hud.Window.Size.Height * 0.27f;
            textBuilder.Clear();
			textBuilder1.Clear();
			WizIngame = false;
            foreach (var player in Hud.Game.Players)
            {
                if (player.HeroClassDefinition.HeroClass == HeroClass.Wizard)
                {
                    WizIngame = true;
                    foreach (var i in _skillOrder)
                    {
                        var skill = player.Powers.SkillSlots[i];
                        if (skill == null || skill.SnoPower.Sno != 134872) continue; //Archon

                        Cooldown = (skill.CooldownFinishTick - Hud.Game.CurrentGameTick) / 60.0d;

                        var buff = player.Powers.GetBuff(Hud.Sno.SnoPowers.Wizard_Archon.Sno);
                        if (buff != null)
                        {
                            ArchonTimeLeft = buff.TimeLeftSeconds[2];
                        }
                        if (Cooldown < 0)
                        {
                            if (skill.Rune == 3.0)
                            {
                                Cooldown = skill.CalculateCooldown(100) - 20 + ArchonTimeLeft;
                            }
                            else
                            {
                                Cooldown = skill.CalculateCooldown(120) - 20 + ArchonTimeLeft;
                            }

                            
                            if(ArchonTimeLeft == 0)
                            {
                                Cooldown = 0;
                            }
                        }
                        textBuilder.Append("Normal ").AppendFormat("{0:0}", Cooldown);
                        textBuilder1.Append("Archon ").AppendFormat("{0:0}", ArchonTimeLeft);
                    }
                }
            }

            if (WizIngame && Hud.Game.SpecialArea == SpecialArea.GreaterRift)
            {
                if (ArchonTimeLeft <= 3f && ArchonTimeLeft > 0f)
                {
                    RedBFont.DrawText("3 seconds to normal", Hud.Window.Size.Width * 0.72f, Hud.Window.Size.Height * 0.3f);
                    if (Hud.Sound.LastSpeak.TimerTest(3000))
                    {
                        Hud.Sound.Speak("3 seconds to normal");
                    }
                }

                if (ArchonTimeLeft == 0)
                {
                    var layout =RedFont.GetTextLayout(textBuilder.ToString());
                    RedFont.DrawText(layout, x, y);
                }
                else
                {
                    var layout =GreenFont.GetTextLayout(textBuilder1.ToString());
                    GreenFont.DrawText(layout, x, y);
                    if (ArchonTimeLeft < 20 && ArchonTimeLeft > 18)
                    {
                        if (Hud.Sound.LastSpeak.TimerTest(2000))
                        {
                            Hud.Sound.Speak("Archon");
                        }
                    }
                }
            }
        }
    }
}