using System;
using System.Linq;
using System.Collections.Generic;
using Turbo.Plugins.Default;

namespace Turbo.Plugins.User
{
    public class EliteHealthBarPlugin : BasePlugin, IInGameTopPainter
    {

        public IFont TextFont { get; set; }
        public IBrush BorderBrush { get; set; }
        public IBrush BackgroundBrush { get; set; }
        public IBrush RareBrush { get; set; }
        public IBrush ChampionBrush { get; set; }
        public int b { get; set; }

        public EliteHealthBarPlugin()
        {
            Enabled = true;
            Order = 100000;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);

            TextFont = Hud.Render.CreateFont("Tahoma", 8, 200, 255, 255, 255, false, false, true);
            BorderBrush = Hud.Render.CreateBrush(255, 0, 100, 0, -1);
            BackgroundBrush = Hud.Render.CreateBrush(255, 0, 0, 0, 0);
            RareBrush = Hud.Render.CreateBrush(255, 255, 128, 0, 0);
            ChampionBrush = Hud.Render.CreateBrush(255, 0, 128, 255, 0);

            b = 25;

        }

        public void PaintTopInGame(ClipState clipState)
        {
            if (Hud.Render.UiHidden) return;
            if (clipState != ClipState.BeforeClip) return;

            var w1 = Hud.Window.Size.Width * 0.00333f * b;
            var h2 = Hud.Window.Size.Height * 0.017f;
            var x2 = Hud.Window.Size.Width * 0.001667f * b;
            var x3 = Hud.Window.Size.Width * 0.02f;

            IBrush brush = null;

            var monsters = Hud.Game.AliveMonsters;

            foreach (var monster in monsters)
            {
                brush = null;

                if (monster.Rarity == ActorRarity.Champion && monster.SummonerAcdDynamicId == 0) // not an illusion
                {
                    brush = ChampionBrush;
                }
                else if (monster.Rarity == ActorRarity.Rare && monster.SummonerAcdDynamicId == 0) // not an illusion
                {
                    brush = RareBrush;
                }
                if (brush != null)
                {
                    var hptext = (monster.CurHealth * 100 / monster.MaxHealth).ToString("F0") + "%";
                    var layout = TextFont.GetTextLayout(hptext);
                    var h = Hud.Window.Size.Height * 0.00034f * 25;
                    var w = monster.CurHealth * w1 / monster.MaxHealth;
                    var monsterX = monster.FloorCoordinate.ToScreenCoordinate().X;
                    var monsterY = monster.FloorCoordinate.ToScreenCoordinate().Y;
                    var hpX = monsterX + w1 / 2 + 3;

                    BackgroundBrush.DrawRectangle(monsterX - x2, monsterY + h2, w1, h);
                    brush.DrawRectangle(monsterX - x2, monsterY + h2, Math.Min((float)w, (float)w1), h);
                    TextFont.DrawText(layout, hpX, monsterY + h2);
                }
            }
        }
    }
}
