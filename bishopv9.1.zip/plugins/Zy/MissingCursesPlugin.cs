using System.Collections.Generic;
using System.Linq;
using System;
using Turbo.Plugins.Default;
namespace Turbo.Plugins.Zy
{
    public class MissingCursesPlugin : BasePlugin, IInGameWorldPainter
    {
        public IFont TextFontFrailty { get; set; }
        public IFont TextFontLeech { get; set; }
        public IFont TextFontDecrepify { get; set; }
        
        public MissingCursesPlugin()
        {
            Enabled = true;
        }
 
        public override void Load(IController hud)
        {
            base.Load(hud);
 
            TextFontFrailty = Hud.Render.CreateFont("calibri", 5, 255, 128, 0, 128, false, false, true);
            TextFontLeech = Hud.Render.CreateFont("calibri", 5, 255, 255, 0, 0, false, false, true);
            TextFontDecrepify = Hud.Render.CreateFont("calibri", 5, 255, 64, 224, 208, false, false, true);
        }
 
        public void PaintWorld(WorldLayer layer)
        {
            if (Hud.Render.UiHidden) return;
            var w1 = 30;
            var py = Hud.Window.Size.Height / 600;
            var monsters = Hud.Game.AliveMonsters.Where(x => x.IsAlive);
 
            var NecroIngame = false;
            foreach (var player in Hud.Game.Players)
            {
                if (player.HeroClassDefinition.HeroClass == HeroClass.Necromancer)
                {
                    NecroIngame = true;
                }
            }
            if (NecroIngame)
            {
                foreach (var monster in monsters)
                {
                    var textFrailty = "";
                    var textLeech = "";
                    var textDecrepify = "";
                    var test = monster.GetAttributeValue(Hud.Sno.Attributes.Power_Buff_2_Visual_Effect_None, 471845);//471845   1   power: Frailty
                    if (test == -1)
                    {
                        textFrailty += "F";
                    }
                    test = monster.GetAttributeValue(Hud.Sno.Attributes.Power_Buff_2_Visual_Effect_None, 471869);//471869   1   power: Leech
                    if (test == -1)
                    {
                        textLeech += "L";
                    }
                    test = monster.GetAttributeValue(Hud.Sno.Attributes.Power_Buff_2_Visual_Effect_None, 471738);//471738   1   power: Decrepify
                    if (test == -1)
                    {
                        textDecrepify += "D";
                    }
                    var layoutFrailty = TextFontFrailty.GetTextLayout(textFrailty);
                    var layoutLeech = TextFontLeech.GetTextLayout(textLeech);
                    var layoutDecrepify = TextFontDecrepify.GetTextLayout(textDecrepify);
                    var w = monster.CurHealth * w1 / monster.MaxHealth;
                    var monsterX = monster.FloorCoordinate.ToScreenCoordinate().X - w1 / 2;
                    var monsterY = monster.FloorCoordinate.ToScreenCoordinate().Y + py * 12;
                    var buffY = monsterY - 1;
                    var hpX = monsterX + 7;
 
                    TextFontFrailty.DrawText(layoutFrailty, hpX - 2, buffY);
                    TextFontLeech.DrawText(layoutLeech, hpX + 6, buffY);
                    TextFontDecrepify.DrawText(layoutDecrepify, hpX + 14, buffY);
                }
            }
        }
    }
}